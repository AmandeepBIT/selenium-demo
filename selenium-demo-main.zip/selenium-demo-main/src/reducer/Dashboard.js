export const initialState = {
  loading: false,
  data: [],
  error: null,
};
export default initialState;
