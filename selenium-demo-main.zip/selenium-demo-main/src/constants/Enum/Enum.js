export const Enums = {
    LogInFields : {        
        Email: 0,
        Password: 1,
    },
    SignUpFields : {        
        Email: 0,
        Password: 1,
        RePass: 2
    }
}